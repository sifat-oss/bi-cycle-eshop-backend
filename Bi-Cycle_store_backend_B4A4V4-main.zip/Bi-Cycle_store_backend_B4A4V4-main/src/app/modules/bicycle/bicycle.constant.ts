export const bicycleSearchTerms = [
  'name',
  'brand',
  'model',
  'type',
  'inStock',
]
