export const userSearchTerm = ['email', 'name', 'role', 'presentAddress']

export const USER_ROLE = {
  admin: 'admin',
  customer: 'customer',
} as const
