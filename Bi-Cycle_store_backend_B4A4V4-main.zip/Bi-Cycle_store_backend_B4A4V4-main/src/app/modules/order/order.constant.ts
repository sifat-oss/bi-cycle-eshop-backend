export const orderSearchTerm = ['status', 'product', 'stock', 'quantity']
